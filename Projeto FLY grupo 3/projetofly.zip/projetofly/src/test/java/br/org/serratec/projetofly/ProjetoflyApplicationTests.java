package br.org.serratec.projetofly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoflyApplicationTests {

	@Test
	void contextLoads() {
	}

}
