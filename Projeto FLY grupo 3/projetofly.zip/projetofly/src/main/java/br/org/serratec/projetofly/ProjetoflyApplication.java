package br.org.serratec.projetofly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoflyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoflyApplication.class, args);
	}

}
